<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<center><p style="color:red; font-size:100px; padding-top: 200px;"><b>WELCOME ADMIN!</p></center>
</body>
</html>